const express = require("express");
const app = express();
require("dotenv").config();
const allowRoles = require("./middleware/roleMiddleware");

app.use(express.json());

app.get("/", (req, res) => {
  res.send("Event Approval System API Running");
});

const authMiddleware = require("./middleware/authMiddleware");

app.get("/api/protected", authMiddleware, (req, res) => {
  res.json({
    message: "You accessed a protected route!",
    user: req.user
  });
});


app.get(
  "/api/admin-only",
  authMiddleware,
  allowRoles("Admin"),
  (req, res) => {
    res.json({ message: "Welcome Admin!" });
  }
);

app.get(
  "/api/club-only",
  authMiddleware,
  allowRoles("Club"),
  (req, res) => {
    res.json({ message: "Welcome Club User!" });
  }
);


app.listen(5000, () => {
  console.log("Server running on port 5000");
});

const pool = require("./config/db");

pool.query("SELECT NOW()")
  .then(res => console.log("DB Connected:", res.rows))
  .catch(err => console.error("DB Error:", err));


const authRoutes = require("./routes/authRoutes");

app.use("/api/auth", authRoutes);